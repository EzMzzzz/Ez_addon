package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;

/**
 * Reach BB - raises block and entity interaction range up to 100 blocks.
 * The actual range override happens in PlayerEntityMixin.
 */
public class ReachBB extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public final Setting<Double> blockReach = sgGeneral.add(new DoubleSetting.Builder()
        .name("block-reach")
        .description("Range for placing / breaking blocks (blocks).")
        .defaultValue(100)
        .min(0).max(100).sliderMin(0).sliderMax(100)
        .build());

    public final Setting<Double> entityReach = sgGeneral.add(new DoubleSetting.Builder()
        .name("entity-reach")
        .description("Range for hitting players and mobs (blocks).")
        .defaultValue(100)
        .min(0).max(100).sliderMin(0).sliderMax(100)
        .build());

    public ReachBB() {
        super(AddonTemplate.CATEGORY, "reach-bb", "Extends your reach up to 100 blocks (block place/break + player/mob hits).");
    }

    @Override
    public String getInfoString() {
        return String.format("%.0f/%.0f", blockReach.get(), entityReach.get());
    }
}

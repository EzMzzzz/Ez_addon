package com.example.addon.util;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.*;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.DeflaterOutputStream;

/** Writes client-side chunks to a vanilla Anvil (.mca) world folder + level.dat. */
public final class WorldSaver {
    private WorldSaver() {}

    // ---------------------------------------------------------------- chunk -> NBT

    public static NbtCompound chunkToNbt(WorldChunk chunk, int dataVersion, RegistryWrapper.WrapperLookup registries) {
        NbtCompound root = new NbtCompound();
        root.putInt("DataVersion", dataVersion);
        root.putInt("xPos", chunk.getPos().x);
        root.putInt("zPos", chunk.getPos().z);
        root.putInt("yPos", chunk.getBottomSectionCoord());
        root.putString("Status", "minecraft:full");
        root.putLong("LastUpdate", 0L);
        root.putLong("InhabitedTime", 0L);
        root.putByte("isLightOn", (byte) 0);

        NbtList sections = new NbtList();
        ChunkSection[] arr = chunk.getSectionArray();
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == null) continue;
            sections.add(sectionToNbt(arr[i], chunk.getBottomSectionCoord() + i));
        }
        root.put("sections", sections);

        NbtList blockEntities = new NbtList();
        for (BlockEntity be : chunk.getBlockEntities().values()) {
            try {
                blockEntities.add(be.createNbtWithIdentifyingData(registries));
            } catch (Throwable ignored) {
                // some client block entities cannot be serialized - skip them
            }
        }
        root.put("block_entities", blockEntities);
        return root;
    }

    private static NbtCompound sectionToNbt(ChunkSection section, int y) {
        NbtCompound sec = new NbtCompound();
        sec.putByte("Y", (byte) y);

        // ---- block states (16x16x16, order: y, z, x)
        List<BlockState> palette = new ArrayList<>();
        Map<BlockState, Integer> index = new HashMap<>();
        int[] ids = new int[4096];
        int n = 0;
        for (int yy = 0; yy < 16; yy++)
            for (int zz = 0; zz < 16; zz++)
                for (int xx = 0; xx < 16; xx++) {
                    BlockState state = section.getBlockState(xx, yy, zz);
                    Integer id = index.get(state);
                    if (id == null) {
                        id = palette.size();
                        palette.add(state);
                        index.put(state, id);
                    }
                    ids[n++] = id;
                }
        NbtCompound blockStates = new NbtCompound();
        NbtList pal = new NbtList();
        for (BlockState s : palette) pal.add(NbtHelper.fromBlockState(s));
        blockStates.put("palette", pal);
        if (palette.size() > 1) {
            int bits = Math.max(4, 32 - Integer.numberOfLeadingZeros(palette.size() - 1));
            blockStates.put("data", new NbtLongArray(pack(ids, bits)));
        }
        sec.put("block_states", blockStates);

        // ---- biomes (4x4x4, order: y, z, x)
        List<String> biomePalette = new ArrayList<>();
        Map<String, Integer> biomeIndex = new HashMap<>();
        int[] bids = new int[64];
        n = 0;
        for (int yy = 0; yy < 4; yy++)
            for (int zz = 0; zz < 4; zz++)
                for (int xx = 0; xx < 4; xx++) {
                    RegistryEntry<Biome> entry = section.getBiome(xx, yy, zz);
                    String name = entry.getKey().map(k -> k.getValue().toString()).orElse("minecraft:plains");
                    Integer id = biomeIndex.get(name);
                    if (id == null) {
                        id = biomePalette.size();
                        biomePalette.add(name);
                        biomeIndex.put(name, id);
                    }
                    bids[n++] = id;
                }
        NbtCompound biomes = new NbtCompound();
        NbtList bpal = new NbtList();
        for (String b : biomePalette) bpal.add(NbtString.of(b));
        biomes.put("palette", bpal);
        if (biomePalette.size() > 1) {
            int bits = 32 - Integer.numberOfLeadingZeros(biomePalette.size() - 1);
            biomes.put("data", new NbtLongArray(pack(bids, bits)));
        }
        sec.put("biomes", biomes);
        return sec;
    }

    /** Bit-packs values without letting an entry span two longs (format used since 1.16). */
    private static long[] pack(int[] values, int bits) {
        int perLong = 64 / bits;
        long[] out = new long[(values.length + perLong - 1) / perLong];
        long mask = (1L << bits) - 1L;
        for (int i = 0; i < values.length; i++) {
            out[i / perLong] |= ((long) values[i] & mask) << ((i % perLong) * bits);
        }
        return out;
    }

    // ---------------------------------------------------------------- region files

    /** chunks: key = ChunkPos.toLong(x, z) packed as (x & 0xFFFFFFFFL) | (z << 32). */
    public static void writeRegions(Path regionDir, Map<Long, NbtCompound> chunks) throws IOException {
        Files.createDirectories(regionDir);

        Map<Long, Map<Integer, byte[]>> regions = new HashMap<>();
        for (Map.Entry<Long, NbtCompound> e : chunks.entrySet()) {
            int cx = (int) (e.getKey() & 0xFFFFFFFFL);
            int cz = (int) (e.getKey() >> 32);
            long rkey = ((long) (cx >> 5) & 0xFFFFFFFFL) | ((long) (cz >> 5) << 32);
            int slot = (cx & 31) + (cz & 31) * 32;

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try (DataOutputStream out = new DataOutputStream(new DeflaterOutputStream(bos))) {
                NbtIo.write(e.getValue(), out);
            }
            regions.computeIfAbsent(rkey, k -> new HashMap<>()).put(slot, bos.toByteArray());
        }

        int now = (int) (System.currentTimeMillis() / 1000L);
        for (Map.Entry<Long, Map<Integer, byte[]>> r : regions.entrySet()) {
            int rx = (int) (r.getKey() & 0xFFFFFFFFL);
            int rz = (int) (r.getKey() >> 32);
            Path file = regionDir.resolve("r." + rx + "." + rz + ".mca");

            byte[] locations = new byte[4096];
            byte[] timestamps = new byte[4096];
            ByteArrayOutputStream body = new ByteArrayOutputStream();
            int nextSector = 2;

            for (Map.Entry<Integer, byte[]> c : new TreeMap<>(r.getValue()).entrySet()) {
                byte[] data = c.getValue();
                int length = data.length + 1;                 // + compression byte
                int total = length + 4;                       // + length field
                int sectors = (total + 4095) / 4096;

                int slot = c.getKey();
                locations[slot * 4] = (byte) (nextSector >> 16);
                locations[slot * 4 + 1] = (byte) (nextSector >> 8);
                locations[slot * 4 + 2] = (byte) nextSector;
                locations[slot * 4 + 3] = (byte) sectors;
                timestamps[slot * 4] = (byte) (now >> 24);
                timestamps[slot * 4 + 1] = (byte) (now >> 16);
                timestamps[slot * 4 + 2] = (byte) (now >> 8);
                timestamps[slot * 4 + 3] = (byte) now;

                byte[] sectorBytes = new byte[sectors * 4096];
                sectorBytes[0] = (byte) (length >> 24);
                sectorBytes[1] = (byte) (length >> 16);
                sectorBytes[2] = (byte) (length >> 8);
                sectorBytes[3] = (byte) length;
                sectorBytes[4] = 2;                           // zlib
                System.arraycopy(data, 0, sectorBytes, 5, data.length);
                body.write(sectorBytes);
                nextSector += sectors;
            }

            try (RandomAccessFile raf = new RandomAccessFile(file.toFile(), "rw")) {
                raf.setLength(0);
                raf.write(locations);
                raf.write(timestamps);
                raf.write(body.toByteArray());
            }
        }
    }

    // ---------------------------------------------------------------- level.dat

    public static void writeLevelDat(Path worldDir, String levelName, int dataVersion, String versionName,
                                     String loaderBrand, boolean modded, int spawnX, int spawnY, int spawnZ,
                                     String spawnDimension) throws IOException {
        NbtCompound data = new NbtCompound();
        data.putInt("version", 19133);
        data.putInt("DataVersion", dataVersion);
        data.putString("LevelName", levelName);
        data.putLong("LastPlayed", System.currentTimeMillis());
        data.putInt("GameType", 1);
        data.putByte("Difficulty", (byte) 2);
        data.putByte("DifficultyLocked", (byte) 0);
        data.putByte("allowCommands", (byte) 1);
        data.putByte("hardcore", (byte) 0);
        data.putByte("initialized", (byte) 1);
        data.putByte("raining", (byte) 0);
        data.putByte("thundering", (byte) 0);
        data.putLong("Time", 0L);
        data.putLong("DayTime", 6000L);

        // spawn (old + new 1.21.9+ layout, the game ignores what it does not know)
        data.putInt("SpawnX", spawnX);
        data.putInt("SpawnY", spawnY);
        data.putInt("SpawnZ", spawnZ);
        data.putFloat("SpawnAngle", 0f);
        NbtCompound spawn = new NbtCompound();
        spawn.put("pos", new NbtIntArray(new int[]{spawnX, spawnY, spawnZ}));
        spawn.putFloat("yaw", 0f);
        spawn.putFloat("pitch", 0f);
        spawn.putString("dimension", spawnDimension);
        data.put("spawn", spawn);

        // loader / version metadata
        data.putByte("WasModded", (byte) (modded ? 1 : 0));
        NbtList brands = new NbtList();
        brands.add(NbtString.of(loaderBrand));
        data.put("ServerBrands", brands);
        NbtCompound version = new NbtCompound();
        version.putInt("Id", dataVersion);
        version.putString("Name", versionName);
        version.putByte("Snapshot", (byte) 0);
        version.putString("Series", "main");
        data.put("Version", version);

        NbtCompound packs = new NbtCompound();
        NbtList enabled = new NbtList();
        enabled.add(NbtString.of("vanilla"));
        packs.put("Enabled", enabled);
        packs.put("Disabled", new NbtList());
        data.put("DataPacks", packs);
        data.put("GameRules", new NbtCompound());

        // Void flat overworld so chunks that were never downloaded stay empty.
        NbtCompound gen = new NbtCompound();
        gen.putLong("seed", 0L);
        gen.putByte("generate_features", (byte) 0);
        gen.putByte("bonus_chest", (byte) 0);
        NbtCompound dims = new NbtCompound();

        NbtCompound overworld = new NbtCompound();
        overworld.putString("type", "minecraft:overworld");
        NbtCompound flat = new NbtCompound();
        flat.putString("type", "minecraft:flat");
        NbtCompound flatSettings = new NbtCompound();
        flatSettings.putString("biome", "minecraft:the_void");
        flatSettings.putByte("features", (byte) 0);
        flatSettings.putByte("lakes", (byte) 0);
        flatSettings.put("layers", new NbtList());
        flatSettings.put("structure_overrides", new NbtList());
        flat.put("settings", flatSettings);
        overworld.put("generator", flat);
        dims.put("minecraft:overworld", overworld);

        NbtCompound nether = new NbtCompound();
        nether.putString("type", "minecraft:the_nether");
        NbtCompound netherGen = new NbtCompound();
        netherGen.putString("type", "minecraft:noise");
        netherGen.putString("settings", "minecraft:nether");
        NbtCompound netherBiome = new NbtCompound();
        netherBiome.putString("type", "minecraft:multi_noise");
        netherBiome.putString("preset", "minecraft:nether");
        netherGen.put("biome_source", netherBiome);
        nether.put("generator", netherGen);
        dims.put("minecraft:the_nether", nether);

        NbtCompound end = new NbtCompound();
        end.putString("type", "minecraft:the_end");
        NbtCompound endGen = new NbtCompound();
        endGen.putString("type", "minecraft:noise");
        endGen.putString("settings", "minecraft:end");
        NbtCompound endBiome = new NbtCompound();
        endBiome.putString("type", "minecraft:the_end");
        endGen.put("biome_source", endBiome);
        end.put("generator", endGen);
        dims.put("minecraft:the_end", end);

        gen.put("dimensions", dims);
        data.put("WorldGenSettings", gen);

        NbtCompound root = new NbtCompound();
        root.put("Data", data);
        Files.createDirectories(worldDir);
        NbtIo.writeCompressed(root, worldDir.resolve("level.dat"));
    }
}

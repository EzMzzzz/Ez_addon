package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.entity.Target;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * SuperKill Aura - Kill Aura style module that never hits friends and uses Reach BB range (up to 100 blocks).
 * Friends are managed with Meteor's normal ".friends add <name>" command.
 */
public class SuperKillAura extends Module {
    public enum Priority { LowestDistance, HighestDistance, LowestHealth, HighestHealth }
    public enum RotationMode { None, OnHit, Always }
    public enum DelayMode { Smart, Fixed }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgTargeting = settings.createGroup("Targeting");
    private final SettingGroup sgTiming = settings.createGroup("Timing");

    private final Setting<Boolean> useReachBB = sgGeneral.add(new BoolSetting.Builder()
        .name("use-reach-bb").description("Use Reach BB (auto-enables it) so the aura can hit up to 100 blocks.")
        .defaultValue(true).build());

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range").description("Max attack range (capped by Reach BB entity-reach when Reach BB is used).")
        .defaultValue(100).min(0).max(100).sliderMin(0).sliderMax(100).build());

    private final Setting<RotationMode> rotation = sgGeneral.add(new EnumSetting.Builder<RotationMode>()
        .name("rotate").description("When to look at the target.").defaultValue(RotationMode.Always).build());

    private final Setting<Boolean> swing = sgGeneral.add(new BoolSetting.Builder()
        .name("swing").description("Swing your hand when attacking.").defaultValue(true).build());

    private final Setting<Boolean> pauseOnUse = sgGeneral.add(new BoolSetting.Builder()
        .name("pause-on-use").description("Do not attack while using an item (eating, blocking...).").defaultValue(false).build());

    private final Setting<Boolean> pauseOnScreen = sgGeneral.add(new BoolSetting.Builder()
        .name("pause-on-screen").description("Do not attack while a GUI is open.").defaultValue(true).build());

    private final Setting<Set<EntityType<?>>> entities = sgTargeting.add(new EntityTypeListSetting.Builder()
        .name("entities").description("Entities to attack.").defaultValue(EntityType.PLAYER).build());

    private final Setting<Priority> priority = sgTargeting.add(new EnumSetting.Builder<Priority>()
        .name("priority").description("How to sort targets.").defaultValue(Priority.LowestDistance).build());

    private final Setting<Integer> maxTargets = sgTargeting.add(new IntSetting.Builder()
        .name("max-targets").description("How many targets to hit per attack.").defaultValue(1).min(1).sliderMax(10).build());

    private final Setting<Boolean> throughWalls = sgTargeting.add(new BoolSetting.Builder()
        .name("through-walls").description("Target entities that are not in line of sight.").defaultValue(true).build());

    private final Setting<Boolean> ignoreBabies = sgTargeting.add(new BoolSetting.Builder()
        .name("ignore-babies").description("Do not attack baby mobs.").defaultValue(true).build());

    private final Setting<Boolean> ignoreTamed = sgTargeting.add(new BoolSetting.Builder()
        .name("ignore-tamed").description("Do not attack your own tamed pets.").defaultValue(true).build());

    private final Setting<DelayMode> delayMode = sgTiming.add(new EnumSetting.Builder<DelayMode>()
        .name("delay-mode").description("Smart = wait for attack cooldown, Fixed = every N ticks.").defaultValue(DelayMode.Smart).build());

    private final Setting<Integer> hitDelay = sgTiming.add(new IntSetting.Builder()
        .name("hit-delay").description("Ticks between attacks in Fixed mode.").defaultValue(11).min(0).sliderMax(60)
        .visible(() -> delayMode.get() == DelayMode.Fixed).build());

    private int tickCounter;

    public SuperKillAura() {
        super(AddonTemplate.CATEGORY, "superkill-aura", "Kill Aura that skips friends and can hit up to 100 blocks using Reach BB.");
    }

    @Override
    public void onActivate() {
        tickCounter = 0;
        if (useReachBB.get()) {
            ReachBB reach = Modules.get().get(ReachBB.class);
            if (reach != null && !reach.isActive()) reach.toggle();
        }
    }

    private double effectiveRange() {
        double r = range.get();
        if (useReachBB.get()) {
            ReachBB reach = Modules.get().get(ReachBB.class);
            if (reach != null && reach.isActive()) r = Math.min(r, reach.entityReach.get());
        }
        return r;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null || !mc.player.isAlive()) return;
        if (pauseOnScreen.get() && mc.currentScreen != null) return;
        if (pauseOnUse.get() && mc.player.isUsingItem()) return;

        tickCounter++;
        if (!delayReady()) return;

        double maxRange = effectiveRange();
        List<Entity> targets = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (isValid(e, maxRange)) targets.add(e);
        }
        if (targets.isEmpty()) return;

        targets.sort(comparator());
        int count = Math.min(maxTargets.get(), targets.size());

        for (int i = 0; i < count; i++) attack(targets.get(i));
        tickCounter = 0;
    }

    private boolean delayReady() {
        if (delayMode.get() == DelayMode.Smart) return mc.player.getAttackCooldownProgress(0.5f) >= 1f;
        return tickCounter >= hitDelay.get();
    }

    private boolean isValid(Entity e, double maxRange) {
        if (e == mc.player || e == mc.cameraEntity) return false;
        if (!(e instanceof LivingEntity living) || !living.isAlive()) return false;
        if (!entities.get().contains(e.getType())) return false;
        if (mc.player.distanceTo(e) > maxRange) return false;

        // Friends list (.friends add <name>) is never attacked.
        if (e instanceof PlayerEntity p) {
            if (Friends.get().isFriend(p)) return false;
            if (p.isSpectator()) return false;
        }
        if (ignoreBabies.get() && living.isBaby()) return false;
        if (ignoreTamed.get() && e instanceof TameableEntity t && t.isTamed() && t.getOwner() == mc.player) return false;
        if (!throughWalls.get() && !PlayerUtils.canSeeEntity(e)) return false;
        return true;
    }

    private Comparator<Entity> comparator() {
        return switch (priority.get()) {
            case LowestDistance -> Comparator.comparingDouble(e -> mc.player.distanceTo(e));
            case HighestDistance -> Comparator.<Entity>comparingDouble(e -> mc.player.distanceTo(e)).reversed();
            case LowestHealth -> Comparator.comparingDouble(e -> ((LivingEntity) e).getHealth());
            case HighestHealth -> Comparator.<Entity>comparingDouble(e -> ((LivingEntity) e).getHealth()).reversed();
        };
    }

    private void attack(Entity target) {
        if (rotation.get() == RotationMode.None) {
            doAttack(target);
        } else {
            Rotations.rotate(Rotations.getYaw(target), Rotations.getPitch(target, Target.Body), 100, () -> doAttack(target));
        }
    }

    private void doAttack(Entity target) {
        if (mc.player == null || mc.interactionManager == null) return;
        mc.interactionManager.attackEntity(mc.player, target);
        if (swing.get()) mc.player.swingHand(Hand.MAIN_HAND);
    }

    @Override
    public String getInfoString() {
        return priority.get().name();
    }
}

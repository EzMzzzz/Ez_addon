package com.example.addon;

import com.example.addon.modules.MapCracker;
import com.example.addon.modules.ReachBB;
import com.example.addon.modules.SuperKillAura;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AddonTemplate extends MeteorAddon {
    public static final Logger LOG = LoggerFactory.getLogger("BB-Addon");
    public static final Category CATEGORY = new Category("BB Addon");

    @Override
    public void onInitialize() {
        LOG.info("Initializing BB Addon");
        Modules.get().add(new ReachBB());
        Modules.get().add(new SuperKillAura());
        Modules.get().add(new MapCracker());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.example.addon";
    }
}

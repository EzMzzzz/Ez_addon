package com.example.addon.mixin;

import com.example.addon.modules.ReachBB;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Overrides the interaction range of the LOCAL player only while ReachBB is enabled. */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {

    @Inject(method = "getBlockInteractionRange", at = @At("HEAD"), cancellable = true)
    private void bb$blockRange(CallbackInfoReturnable<Double> cir) {
        ReachBB reach = bb$reach();
        if (reach != null && bb$isLocal()) cir.setReturnValue(reach.blockReach.get());
    }

    @Inject(method = "getEntityInteractionRange", at = @At("HEAD"), cancellable = true)
    private void bb$entityRange(CallbackInfoReturnable<Double> cir) {
        ReachBB reach = bb$reach();
        if (reach != null && bb$isLocal()) cir.setReturnValue(reach.entityReach.get());
    }

    private boolean bb$isLocal() {
        return MinecraftClient.getInstance().player == (Object) this;
    }

    private static ReachBB bb$reach() {
        Modules modules = Modules.get();
        if (modules == null) return null;
        ReachBB reach = modules.get(ReachBB.class);
        return reach != null && reach.isActive() ? reach : null;
    }
}

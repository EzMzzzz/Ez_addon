package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import com.example.addon.util.WorldSaver;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Map Cracker - remembers every chunk your client receives while the module is on and, when you turn it
 * off (or leave the server), saves them as a normal world folder in .minecraft/saves.
 * NOTE: a client only ever receives the chunks the server sends it (render distance) - fly around to capture more.
 */
public class MapCracker extends Module {
    public enum TargetVersion {
        V1_21_10("1.21.10", 4556),
        V1_21_11("1.21.11", 4671);

        public final String label;
        public final int dataVersion;
        TargetVersion(String label, int dataVersion) { this.label = label; this.dataVersion = dataVersion; }
    }

    public enum Loader {
        Vanilla("vanilla", false),
        Fabric("fabric", true),
        Forge("forge", true),
        NeoForge("neoforge", true),
        Quilt("quilt", true);

        public final String brand;
        public final boolean modded;
        Loader(String brand, boolean modded) { this.brand = brand; this.modded = modded; }
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<TargetVersion> version = sgGeneral.add(new EnumSetting.Builder<TargetVersion>()
        .name("minecraft-version").description("Minecraft version written into the saved world.")
        .defaultValue(TargetVersion.V1_21_11).build());

    private final Setting<Loader> loader = sgGeneral.add(new EnumSetting.Builder<Loader>()
        .name("loader").description("Loader brand written into the saved world.")
        .defaultValue(Loader.Fabric).build());

    private final Setting<Integer> scanInterval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval").description("Ticks between chunk scans.")
        .defaultValue(10).min(1).sliderMax(100).build());

    private final Setting<Boolean> saveOnLeave = sgGeneral.add(new BoolSetting.Builder()
        .name("save-on-leave").description("Also save automatically when you disconnect.")
        .defaultValue(true).build());

    // dimension id -> (packed chunk pos -> chunk)
    private final Map<String, Map<Long, WorldChunk>> captured = new HashMap<>();
    private RegistryWrapper.WrapperLookup registries;
    private String worldName = "world";
    private int spawnX, spawnY, spawnZ;
    private String spawnDim = "minecraft:overworld";
    private int ticks;

    public MapCracker() {
        super(AddonTemplate.CATEGORY, "map-cracker", "Downloads the world you are in (the chunks you receive) as a save folder.");
    }

    @Override
    public void onActivate() {
        captured.clear();
        ticks = 0;
        if (mc.world == null || mc.player == null) {
            error("Join a world first.");
            toggle();
            return;
        }
        registries = mc.world.getRegistryManager();
        info("Recording chunks. Walk/fly around, then turn the module off to save.");
    }

    @Override
    public void onDeactivate() {
        save();
    }

    @EventHandler
    private void onLeave(GameLeftEvent event) {
        if (isActive() && saveOnLeave.get()) {
            save();
            captured.clear();
            toggle();
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.world == null || mc.player == null) return;
        if (++ticks % scanInterval.get() != 0) return;

        String dim = mc.world.getRegistryKey().getValue().toString();
        Map<Long, WorldChunk> map = captured.computeIfAbsent(dim, k -> new HashMap<>());

        int radius = mc.options.getViewDistance().getValue() + 1;
        int pcx = mc.player.getChunkPos().x;
        int pcz = mc.player.getChunkPos().z;
        for (int x = pcx - radius; x <= pcx + radius; x++) {
            for (int z = pcz - radius; z <= pcz + radius; z++) {
                Chunk c = mc.world.getChunk(x, z, ChunkStatus.FULL, false);
                if (c instanceof WorldChunk wc) map.put(ChunkPos.toLong(x, z), wc);
            }
        }

        // remember names / spawn for level.dat
        worldName = currentWorldName();
        spawnX = (int) mc.player.getX();
        spawnY = (int) mc.player.getY();
        spawnZ = (int) mc.player.getZ();
        spawnDim = dim;
        registries = mc.world.getRegistryManager();
    }

    private String currentWorldName() {
        if (mc.getCurrentServerEntry() != null) return mc.getCurrentServerEntry().address;
        return "singleplayer";
    }

    private void save() {
        if (captured.isEmpty() || registries == null) return;
        try {
            String safe = worldName.replaceAll("[^a-zA-Z0-9._-]", "_");
            String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
            Path worldDir = mc.runDirectory.toPath().resolve("saves").resolve("MapCracker_" + safe + "_" + stamp);

            int total = 0;
            for (Map.Entry<String, Map<Long, WorldChunk>> dimEntry : captured.entrySet()) {
                Map<Long, NbtCompound> nbt = new HashMap<>();
                for (Map.Entry<Long, WorldChunk> c : dimEntry.getValue().entrySet()) {
                    try {
                        nbt.put(c.getKey(), WorldSaver.chunkToNbt(c.getValue(), version.get().dataVersion, registries));
                    } catch (Throwable t) {
                        AddonTemplate.LOG.warn("Could not serialize chunk", t);
                    }
                }
                WorldSaver.writeRegions(regionDirFor(worldDir, dimEntry.getKey()), nbt);
                total += nbt.size();
            }

            WorldSaver.writeLevelDat(worldDir, "MapCracker " + safe, version.get().dataVersion, version.get().label,
                loader.get().brand, loader.get().modded, spawnX, spawnY, spawnZ, spawnDim);

            info("Saved %d chunks to saves/%s", total, worldDir.getFileName());
        } catch (Throwable t) {
            AddonTemplate.LOG.error("Map Cracker save failed", t);
            error("Save failed: %s (see logs/latest.log)", t.getMessage());
        }
    }

    private static Path regionDirFor(Path worldDir, String dimension) {
        Identifier id = Identifier.of(dimension);
        return switch (dimension) {
            case "minecraft:overworld" -> worldDir.resolve("region");
            case "minecraft:the_nether" -> worldDir.resolve("DIM-1").resolve("region");
            case "minecraft:the_end" -> worldDir.resolve("DIM1").resolve("region");
            default -> worldDir.resolve("dimensions").resolve(id.getNamespace()).resolve(id.getPath()).resolve("region");
        };
    }

    @Override
    public String getInfoString() {
        int n = 0;
        for (Map<Long, WorldChunk> m : captured.values()) n += m.size();
        return n + " chunks";
    }
}

# BB Addon برای Meteor Client (Fabric 1.21.10 / 1.21.11)

ماژول‌ها (دسته‌ی «BB Addon» در GUI متعور):
- reach-bb          : ریچ تا 100 بلاک (بلاک گذاشتن/شکستن + زدن پلیر و مابی)
- superkill-aura    : مثل کیل‌اورا، دوستان (.friends add) رو نمی‌زنه، از Reach BB استفاده می‌کنه
- map-cracker       : چانک‌های مپی که داخلش هستی رو داخل saves ذخیره می‌کنه (انتخاب ورژن و لودر در ستینگ)

## ساخت فایل .jar (قدم به قدم)

1) نصب JDK 21 (مثلاً Temurin 21) و (اختیاری) Git.
2) گرفتن تمپلیت رسمی:
   git clone --depth 1 https://github.com/MeteorDevelopment/meteor-addon-template bb-addon
3) فایل‌های این زیپ را روی پروژه کپی کن (جایگزین شوند):
   - src/main/java/com/example/addon/AddonTemplate.java
   - src/main/java/com/example/addon/modules/*  (ReachBB, SuperKillAura, MapCracker)
   - src/main/java/com/example/addon/mixin/PlayerEntityMixin.java
   - src/main/java/com/example/addon/util/WorldSaver.java
   - src/main/resources/addon-template.mixins.json
   فایل‌های نمونه‌ی تمپلیت (ModuleExample, CommandExample, HudExample, ExampleMixin) را پاک کن.
4) فایل gradle/libs.versions.toml را باز کن و برای ورژن مورد نظر این‌ها را تنظیم کن:
   minecraft = "1.21.11"          (یا 1.21.10)
   yarn-mappings = <ورژن yarn همان ماینکرفت>   (از fabricmc.net/develop)
   fabric-loader = <آخرین لودر>
   meteor = "1.21.11-SNAPSHOT"    (یا 1.21.10-SNAPSHOT)
5) در پوشه‌ی پروژه:
   Windows : gradlew.bat build
   Linux/Mac: ./gradlew build
6) فایل خروجی: build/libs/addon-template-0.1.0.jar  (فایل *-sources.jar را نگیر)
7) برای هر ورژن جدا بیلد کن (یک بار 1.21.10 و یک بار 1.21.11) و jar را کنار Fabric API و Meteor Client
   همان ورژن داخل پوشه‌ی mods بگذار.

اگر موقع بیلد/لود خطا داد، متن خطا را برای من بفرست تا درستش کنیم.
